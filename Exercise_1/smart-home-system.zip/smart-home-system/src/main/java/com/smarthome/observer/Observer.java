
package com.smarthome.observer;
public interface Observer {
    void update(Event event);
}
