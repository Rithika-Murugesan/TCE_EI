
package com.smarthome.exceptions;
public class DeviceNotFoundException extends Exception {
    public DeviceNotFoundException(String msg) { super(msg); }
}
