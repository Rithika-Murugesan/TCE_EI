
package com.smarthome.exceptions;
public class TransientDeviceException extends Exception {
    public TransientDeviceException(String msg) { super(msg); }
}
